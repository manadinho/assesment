<?php if(session('success')): ?>

  <div class="alert alert-success" style="background-color:	#B0E0E6">
    <a href="#" data-dismiss="alert" class="close" aria-label="close"></a>
      <strong>Success!</strong> <?php echo e(session('success')); ?>

      <a href="#" class="close" id="btn">&times;</a>
  </div>

  <script> 
    window.setTimeout(function() {
        $(".alert").fadeTo(500, 0).slideUp(500, function(){
            $(this).remove(); 
        });
    }, 4000);
  </script>

<?php endif; ?>

<?php if(session('fail')): ?>

  <div class="alert alert-danger">
    <a href="#" data-dismiss="alert" class="close" aria-label="close"></a>
      <strong>Fail!</strong> <?php echo e(session('fail')); ?>

      <a href="#" class="close" id="btn">&times;</a>
  </div>

  <script> 
    window.setTimeout(function() {
        $(".alert").fadeTo(500, 0).slideUp(500, function(){
            $(this).remove(); 
        });
    }, 4000);
  </script>

<?php endif; ?>
<?php /**PATH C:\laragon\www\assessment\resources\views/partials/notifications.blade.php ENDPATH**/ ?>