
<?php $__env->startSection('content'); ?>
<p><center><b style="font-size: 30px;">Admin dashboard</b></center></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\assessment\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>