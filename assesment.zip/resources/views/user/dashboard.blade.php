@extends('layouts.app')
@section('content')
<p><center><b style="font-size: 30px;">User dashboard</b></center></p>
@endsection