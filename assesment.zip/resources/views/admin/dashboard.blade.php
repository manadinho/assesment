@extends('layouts.app')
@section('content')
<p><center><b style="font-size: 30px;">Admin dashboard</b></center></p>
@endsection
